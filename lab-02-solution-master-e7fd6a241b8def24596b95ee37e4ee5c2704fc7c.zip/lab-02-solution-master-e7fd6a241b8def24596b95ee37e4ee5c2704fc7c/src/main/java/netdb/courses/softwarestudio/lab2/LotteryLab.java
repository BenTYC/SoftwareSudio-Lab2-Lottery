package netdb.courses.softwarestudio.lab2;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import netdb.courses.softwarestudio.lab2.lottery.LotteryTicket;
import netdb.courses.softwarestudio.lab2.lottery.NumberGenerator;

public class LotteryLab {

	private static int[] winningNumbers = { 0, 0, 0, 0, 0, 0 };

	public static void main(String[] args) throws Exception {

		// =========== Solution ===========

		// check arguments (not required)
		if (args.length < 3) {
			System.out.println("Inputs: [From] [To] [Count] (Ex: 1 42 6 => pick 6 numbers from 1 to 42)");
			return;
		}

		// parse the arguments 'from', 'to', 'count'.
		int from = Integer.parseInt(args[0]);
		int to = Integer.parseInt(args[1]);
		int count = Integer.parseInt(args[2]);

		// use NumberGenerator to generate the winning numbers
		winningNumbers = NumberGenerator.generateWinningNumbers(from, to, count);

		// =========== End of Solution ===========

		// print the winning numbers
		printNumbers("Winning Numbers: ", winningNumbers);

		// create a scanner for input
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		// print the user interaction message
		System.out.println("Please enter your ticket numbers: (ex:'1 2 3 4 5 6')");
		String inputString = "";

		// read a line and create a new ticket from input string
		while (!(inputString = reader.readLine()).equals("quit")) {
			printNumbers("Your ticket numbers: ", inputString);

			// =========== Solution ===========

			// split the input string
			String[] strings = inputString.split(" ");

			// check the amount of numbers
			if (strings.length != count) {
				System.out.println("Please enter " + count + " numbers:");
				continue;
			}

			// create an integer array
			int[] inputNumbers = new int[count];

			// parse the input string and store it in the array
			for (int i = 0; i < count; i++)
				inputNumbers[i] = Integer.parseInt(strings[i]);

			// check repeated numbers
			if (checkRepeatedNum(inputNumbers)) {
				System.out.println("There is a repeated number, please enter nonrepeated numbers:");
				continue;
			}
			
			// check the range of the numbers 
			if (checkOutOfRange(inputNumbers, from, to)) {
				System.out.println("Please enter the numbers in "+from+" ~ "+to+":");
				continue;
			}

			// create a LotteryTicket
			LotteryTicket ticket = new LotteryTicket(inputNumbers);

			// raffle
			int numOfMatch = ticket.raffle(winningNumbers);

			// print result
			System.out.println("You match " + numOfMatch + " numbers!!");

			// =========== End of Solution ===========

			// prepare for the next loop
			Thread.sleep(1000);
			System.out.println("\nPlease enter your ticket numbers: (ex:'1 2 3 4 5 6')");
		}

		System.out.println("\nGoodbye~");

	}

	private static void printNumbers(String info, int[] numbers) {
		System.out.print(info + " ");
		for (Integer i : numbers)
			System.out.print(i + " ");
		System.out.println();
	}

	private static void printNumbers(String info, String numbers) {
		System.out.println(info + " " + numbers);
	}
	
	private static boolean checkRepeatedNum(int[] nums) {
		for (int i = 0; i < nums.length; i++){
			for (int j = i+1; j < nums.length; j++){
				if(nums[i] == nums[j]){
					return true;
				}
			}
		}
		return false;
	}
	
	private static boolean checkOutOfRange(int[] nums, int from, int to) {
		for (int i = 0; i < nums.length; i++){
			if(nums[i] > to || nums[i] < from){
				return true;
			}
		}
		return false;
	}

}

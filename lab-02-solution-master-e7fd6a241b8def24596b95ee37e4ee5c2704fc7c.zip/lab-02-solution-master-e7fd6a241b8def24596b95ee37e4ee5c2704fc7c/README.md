# Lab 02 Solution

This is the solution to lab 2 assignment of software studio.



## Goal

We want to create a lottery service. User can selet some numbers and service will generate a set of winning numbers. Finally, the user will be informed about the number of hitting.


## Solution

According the specification, we need to implement 2 classes:
* `NumberGenerator.java` - the role to generate random non-repeated winning numbers
* `LotteryTicket.java` - the user's lottery ticket

Then, export them to `.jar`, and import them to project `lab2` TA provided and complete it.


---

### NumberGenerator.java

According to the UML TA define, our `NumberGenerator.java` only contains one public static method which named `generateWinningNumbers` should be like this:

```java
package netdb.courses.softwarestudio.lab2.lottery;

public class NumberGenerator {
	public static int[] generateWinningNumbers(int from, int to, int count) {
        // any algorithm for generating non-reeated numbers
    }
}
```

More challenging is the algorithm for generating non-repeated numbers. Here, TA provided 3 different algorithm:
* Lazy check
* Shuffle
* Knuth Shuffle


#### Lazy Check Algorithm

We call this algorithm lazy because it may need to abort many time, and it's very inefficient.

Lazy Check Algorithm:
1.  Generate a random number
*   Check if this number is repeated
*   If repeated, back to step 1; If no, store it!
*   Repeated above steps until generate enough numbers we want.

The code may be like this:
```java
// Create an integer array to store results
int[] winningNumbers = new int[count];

// Calculate range
int range = to - from + 1;

// Generate n numbers
for (int i = 0; i < count; i++) {

	// Random generate number in (0 ~ range - 1)
	winningNumbers[i] = (int) (Math.random() * range);

	// Shift randomNum to (from ~ to)
	winningNumbers[i] += from;

	// Check if this number exists
	for (int j = 0; j < i; j++)
		if (winningNumbers[j] == winningNumbers[i]) {
			i--;
			break;
		}
}

return winningNumbers;
```

#### Shuffle Algorithm

This algorithm is like shuffle in a card game. It's much more efficient than lazy check algorithm.

Shuffle Algorithm:
1.  Generate a ordering sequence contains all possible and unique numbers, like [1, 2, 3 ... 42].
*   Exchange their positions randomly.
*   After exchanging enough times, just take the enough top numbers.

The code may be like this:
```java
// Create an integer array to store results
int[] winningNumbers = new int[count];

// Create another array to shuffle
int range = to - from + 1;
int[] numbers = new int[range];
for (int i = 0, initNum = from; i < range; i++, initNum++)
	numbers[i] = initNum;

// Shuffle enough times
for (int i = 0; i < 10000; i++) {
	// Random generate positions (0 ~ range - 1)
	int pos1 = (int) (Math.random() * range);
	int pos2 = (int) (Math.random() * range);

	// Change numbers
	int tmp = numbers[pos1];
	numbers[pos1] = numbers[pos2];
	numbers[pos2] = tmp;
}

// Copy the first [count] numbers to winningNumbers
for (int i = 0; i < count; i++)
	winningNumbers[i] = numbers[i];

return winningNumbers;
```

#### Knuth Shuffle Algorithm

This algorithm is not really shuffle. We just pick position randomly and update the range until we get enough numbers.

Knuth Shuffle Algorithm:
1.  Generate a ordering sequence contains all possible and unique numbers, like [1, 2, 3 ... 42].
*   Pick one number randomly.
*   Move the number at last position to the position of picked number, and update the amount of available numbers.
*   Repeat step 2 & 3 until we get enough numbers.

The code may be like this:
```java
// Create an integer array to store result
int[] winningNumbers = new int[count];

// Create another array to sample
int range = to - from + 1;
int[] numbers = new int[range];
for (int i = 0, initNum = from; i < range; i++, initNum++)
	numbers[i] = initNum;

// Generate n numbers
for (int i = 0; i < count; i++) {

	// Generate a position to sample
	int samplePos = (int) (Math.random() * range);

	// Assignment the number to the result array
	winningNumbers[i] = numbers[samplePos];

	// Replace the selected position by the number at the last position
	numbers[samplePos] = numbers[range - 1];

	// Update the range
	range--;
}
return winningNumbers;
```

---
### LotteryTicket.java


According to the UML TA define, our `LotteryTicket.java` has:
*   A private integer array field
*   A public constructor with a integer array parameter
*   A public method returning integer array with a integer array parameter

So, the structure of `LotteryTicket.java` should be like this:
```java
public class LotteryTicket {

	private int[] numbers;

	public LotteryTicket(int[] inputs) {
        // ...
	}

	public int raffle(int[] winningNumbers) {
        // ...
	}
}
```

Constructor is a method to create an object of a class. Here, the constructor `LotteryTicket(int[] inputs)` is the method to create a `LotteryTicket` object. So, we need to fill the value of all fields in this constructor. We just store the parameter to the field easily. It may like this:
```java
public LotteryTicket(int[] inputs) {
	// store the numbers
	numbers = inputs;
}
```

Raffling means to check the hitting numbers. So, we need to use two for-loops to check every number of winning numbers and selected numbers. It may like this:
```java
public int raffle(int[] winningNumbers) {
    int numOfMatch = 0;

    // check number one by one
    for (int i = 0; i < numbers.length; i++)
    	for (int j = 0; j < winningNumbers.length; j++)
    		if (numbers[i] == winningNumbers[j]) {
    			numOfMatch++;
    			break;
    		}

    return numOfMatch;
}
```

---

### LotteryLab.java

This class contains the static main method, so it control the workflow of lottery service.

There are 2 TODOs in this class:
*	First:  
    1.  Assign the parameters passed in begin.
    2.  Use the static method `generateNumbers(int from, int to, int count)` in class `NumberGenerator.java`. It is a static method, so we don't create an object.


*	Second:
	1.  Parse the numbers user enter.
    2.   Create a `LotteryTicket` object with the numbers user enter.
    3.  Raffle with winning numbers we generated before.

# Note

1.	If you code will export to a jar file, you need to specify a package. After setting build path, you can put following code to the top of the class to import the jar files:
	```java
	import netdb.courses.softwarestudio.lab2.lottery.NumberGenerator;
	import netdb.courses.softwarestudio.lab2.lottery.LotteryTicket;
	```

2.	The range of `Math.random()` = [0, 1). So, if you want to get the specific numbers, you need to modify it like this:
```java
int randomNum = (int) (Math.random() * (to - from + 1)) + from;
```
